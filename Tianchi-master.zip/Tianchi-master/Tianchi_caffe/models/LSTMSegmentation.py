#encoding:utf-8
import caffe
import numpy as np
from caffe import layers as L
from caffe import params as P
