python test_seg-Copy1.py main --img_dir='/home/x/data/datasets/tianchi/test2/' --save_dir='/mnt/7/0704_test_64_80/' 
#python test_seg-Copy1.py main --img_dir='/home/x/data/datasets/tianchi/train/' --save_dir='/mnt/7/0704_train_48_64/' 
#python test_seg.py main --img_dir='/home/x/data/datasets/tianchi/train/' --save_dir='/mnt/7/0703_train_no_normalization/'
#python test_class.py doTest  --img_dir='/mnt/7/0703_test_no_normalization/' --csv_file=0703_test_no.csv
#python collection/process.py check_nodule test1_no.csv test1_yes.csv
#python test_class.py doTest  --img_dir='/mnt/7/0703_train_no_normalization/' --csv_file=0703_train_no.csv
#python collection/process.py check_nodule train1_no.csv train1_yes.csv

#unknow result%run -i test_class-Copy2.py doTest --csv_file=0720_test_no.csv --model_dir3="checkpoints/1_iso_classifier_0720_00:49:33.pth" --img_dir='/mnt/7/0704_test_64_80/'


#0.75  %run -i test_class-Copy2.py doTest --csv_file=0719_test_no.csv --model_dir3="checkpoints/1_iso_classifier_0719_21:01:36.pth" 
 
