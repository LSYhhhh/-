from classifier_luna2016 import Luna2016
from classifier_mutliconv import MutltiCNN
from Classifier import Classifier
from SegRes import Segmentation as Seg
Segmentation = Seg
from loss import classifier_loss,loss4multi 
from classifier_luna2016_2 import Luna20162 as L2
from Classifier_iso import Classifier as iso_Classifier
from Classifier_iso import Classifier_1 as iso_Classifier_1