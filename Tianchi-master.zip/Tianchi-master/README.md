
## 天池医疗AI大赛[第一季]：肺部结节智能诊断代码整理

最终在2887队伍中取得了第八名的成绩

- [`pytorch`](/pytorch/) PyTorch版本代码, 最成熟的一份代码,分数最高(初赛的数据能达到0.75)
- `Tianchi-caffe` Caffe 版本代码, 复赛线上平台使用(0.60)
- `Tianchi_tensorflow` tensorflow代码, 最早版本的代码(0.5)

代码的说明，请参照具体文件夹下的README(目前主要是PyTorch的代码说明)

具体方法介绍, 请**点个赞**或者**回复**一下,谢谢
https://tianchi.aliyun.com/competition/new_articleDetail.html?postsId=3099
